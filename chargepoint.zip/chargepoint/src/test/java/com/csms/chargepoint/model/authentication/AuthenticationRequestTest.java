package com.csms.chargepoint.model.authentication;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.csms.chargepoint.model.authorization.AuthorizationRequest;

class AuthenticationRequestTest {

  @Test
  void testBuilderAndGetters() {
    AuthorizationRequest authReq = new AuthorizationRequest();
    authReq.setStationUuid("station-001");

    AuthenticationRequest request = AuthenticationRequest.builder()
        .requestId("req-123")
        .authorizationRequest(authReq)
        .build();

    assertEquals("req-123", request.getRequestId());
    assertEquals(authReq, request.getAuthorizationRequest());
  }
}
