package com.csms.chargepoint.model.authorization;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class AuthorizationRequestTest {

  @Test
  void testGettersAndSetters() {
    AuthorizationRequest request = new AuthorizationRequest();

    request.setStationUuid("station-001");
    DriverIdentifier driver = new DriverIdentifier();
    driver.setId("driver-123");
    request.setDriverIdentifier(driver);

    assertEquals("station-001", request.getStationUuid());
    assertEquals(driver, request.getDriverIdentifier());
  }

  @Test
  void testAllArgsConstructor() {
    DriverIdentifier driver = new DriverIdentifier("driver-456");
    AuthorizationRequest request = new AuthorizationRequest("station-002", driver);

    assertEquals("station-002", request.getStationUuid());
    assertEquals(driver, request.getDriverIdentifier());
  }
}
