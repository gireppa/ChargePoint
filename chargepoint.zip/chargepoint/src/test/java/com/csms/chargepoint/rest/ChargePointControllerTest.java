package com.csms.chargepoint.rest;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.csms.chargepoint.consumer.AuthenticationResponseConsumer;
import com.csms.chargepoint.model.authorization.AuthorizationRequest;
import com.csms.chargepoint.model.authorization.DriverIdentifier;
import com.csms.chargepoint.publisher.AuthenticationPublisher;

@WebMvcTest(ChargePointController.class)
class ChargePointControllerTest {

  @Autowired
  private MockMvc mockMvc;

  @InjectMocks
  private AuthenticationPublisher authenticationPublisher;

  @InjectMocks
  private AuthenticationResponseConsumer authenticationResponseConsumer;

  private AuthorizationRequest validRequest;

  @BeforeEach
  void setup() {
    validRequest = new AuthorizationRequest();
    validRequest.setStationUuid("station-123");
    DriverIdentifier driverIdentifier = new DriverIdentifier();
    driverIdentifier.setId("driver-123");
    validRequest.setDriverIdentifier(driverIdentifier);
  }

  /*@Test
  void testAuthorize_Success() throws Exception {
    AuthorizationResponse mockResponse = new AuthorizationResponse();
    mockResponse.setAuthorizationStatus("Accepted");

    AuthenticationPublisher publisher = mock(AuthenticationPublisher.class);
    AuthenticationResponseConsumer consumer = mock(AuthenticationResponseConsumer.class);
    CompletableFuture<AuthorizationResponse> future = CompletableFuture.completedFuture(mockResponse);
    when(consumer.registerRequest("evchargingstation-centralhub-001")).thenReturn(future);
    doNothing().when(publisher.sendAuthenticationRequest(any(AuthenticationRequest.class), any(String.class)))
        .someVoidMethod();
    mockMvc.perform(post("/authenticate")
            .contentType(MediaType.APPLICATION_JSON)
            .content("""
                                {
                                  "stationUuid": "station-123",
                                  "driverIdentifier": { "id": "driver-123" }
                                }
                                """))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.authorizationStatus", is("Accepted")));

    verify(authenticationPublisher, times(1))
        .sendAuthenticationRequest(any(AuthenticationRequest.class), any(String.class));
  }*/

  @Test
  void testAuthorize_BadRequest_MissingStationUuid() throws Exception {
    mockMvc.perform(post("/authenticate")
            .contentType(MediaType.APPLICATION_JSON)
            .content("""
                                {
                                  "stationUuid": "",
                                  "driverIdentifier": { "id": "driver-123" }
                                }
                                """))
        .andExpect(status().isInternalServerError()); // Because controller catches and returns 500
  }

  @Test
  void testAuthorize_BadRequest_MissingDriverId() throws Exception {
    mockMvc.perform(post("/authenticate")
            .contentType(MediaType.APPLICATION_JSON)
            .content("""
                                {
                                  "stationUuid": "station-123",
                                  "driverIdentifier": { "id": "" }
                                }
                                """))
        .andExpect(status().isInternalServerError());
  }
}

