package com.csms.chargepoint.publisher;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.kafka.core.KafkaTemplate;

import com.csms.chargepoint.model.authentication.AuthenticationRequest;

class AuthenticationPublisherTest {

  private KafkaTemplate<String, AuthenticationRequest> kafkaTemplate;
  private AuthenticationPublisher publisher;

  @BeforeEach
  void setUp() {
    kafkaTemplate = mock(KafkaTemplate.class);
    publisher = new AuthenticationPublisher(kafkaTemplate);
  }

  @Test
  void testSendAuthenticationRequest() {
    AuthenticationRequest request = AuthenticationRequest.builder()
        .requestId("corr-123")
        .build();

    String correlationId = "corr-123";

    // Call method
    publisher.sendAuthenticationRequest(request, correlationId);

    // Capture parameters passed to kafkaTemplate.send()
    ArgumentCaptor<String> topicCaptor = ArgumentCaptor.forClass(String.class);
    ArgumentCaptor<String> keyCaptor = ArgumentCaptor.forClass(String.class);
    ArgumentCaptor<AuthenticationRequest> requestCaptor = ArgumentCaptor.forClass(AuthenticationRequest.class);

    verify(kafkaTemplate, times(1))
        .send(topicCaptor.capture(), keyCaptor.capture(), requestCaptor.capture());

    assertEquals("auth-requests", topicCaptor.getValue());
    assertEquals(correlationId, keyCaptor.getValue());
    assertEquals(request, requestCaptor.getValue());
  }
}
