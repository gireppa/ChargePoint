package com.csms.chargepoint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChargepointApplicationTests {

	@Test
	void contextLoads() {
	}

}
