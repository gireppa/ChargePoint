package com.csms.chargepoint.consumer;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.csms.chargepoint.model.authentication.AuthenticationResponse;
import com.csms.chargepoint.model.authorization.AuthorizationResponse;

class AuthenticationResponseConsumerTest {

  private AuthenticationResponseConsumer consumer;

  @BeforeEach
  void setUp() {
    consumer = new AuthenticationResponseConsumer();
  }

  @Test
  void testRegisterRequest_ReturnsNewFuture() {
    String correlationId = "corr-123";
    CompletableFuture<AuthorizationResponse> future = consumer.registerRequest(correlationId);

    assertNotNull(future);
    assertFalse(future.isDone());
  }

  @Test
  void testConsume_CompletesFuture() throws Exception {
    String correlationId = "corr-456";
    CompletableFuture<AuthorizationResponse> future = consumer.registerRequest(correlationId);

    AuthenticationResponse authResponse = AuthenticationResponse.builder()
        .requestId(correlationId)
        .authorizationStatus("Accepted")
        .build();

    consumer.consume(authResponse);

    // Wait for future to complete (timeout 1s)
    AuthorizationResponse result = future.get(1, TimeUnit.SECONDS);

    assertNotNull(result);
    assertEquals("Accepted", result.getAuthorizationStatus());
  }

  @Test
  void testConsume_UnknownCorrelationId_DoesNotFail() {
    AuthenticationResponse authResponse = AuthenticationResponse.builder()
        .requestId("unknown-corr-id")
        .authorizationStatus("Rejected")
        .build();

    // Just invoke consume; nothing to assert — should not throw
    assertDoesNotThrow(() -> consumer.consume(authResponse));
  }
}
