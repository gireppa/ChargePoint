package com.csms.chargepoint.model.authorization;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class AuthorizationResponseTest {

  @Test
  void testGettersAndSetters() {
    AuthorizationResponse response = new AuthorizationResponse();

    response.setAuthorizationStatus("Accepted");

    assertEquals("Accepted", response.getAuthorizationStatus());
  }

  @Test
  void testAllArgsConstructor() {
    AuthorizationResponse response = new AuthorizationResponse("Rejected");

    assertEquals("Rejected", response.getAuthorizationStatus());
  }
}
