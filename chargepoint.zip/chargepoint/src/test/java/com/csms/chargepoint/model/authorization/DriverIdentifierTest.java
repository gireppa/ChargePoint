package com.csms.chargepoint.model.authorization;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class DriverIdentifierTest {

  @Test
  void testGettersAndSetters() {
    DriverIdentifier driver = new DriverIdentifier();

    driver.setId("driver-123");

    assertEquals("driver-123", driver.getId());
  }

  @Test
  void testAllArgsConstructor() {
    DriverIdentifier driver = new DriverIdentifier("driver-456");

    assertEquals("driver-456", driver.getId());
  }
}
