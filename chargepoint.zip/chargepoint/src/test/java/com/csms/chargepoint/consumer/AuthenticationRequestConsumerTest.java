package com.csms.chargepoint.consumer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.kafka.core.KafkaTemplate;

import com.csms.chargepoint.model.authentication.AuthenticationRequest;
import com.csms.chargepoint.model.authentication.AuthenticationResponse;
import com.csms.chargepoint.model.authorization.AuthorizationRequest;
import com.csms.chargepoint.model.authorization.DriverIdentifier;

class AuthenticationRequestConsumerTest {

  private KafkaTemplate<String, AuthenticationResponse> kafkaTemplate;
  private AuthenticationRequestConsumer consumer;

  @BeforeEach
  void setUp() {
    kafkaTemplate = mock(KafkaTemplate.class);
    consumer = new AuthenticationRequestConsumer(kafkaTemplate);
  }

  @Test
  void testAuthorize_Accepted() {
    String acceptedId = "evchargingstation-centralhub-001";
    String result = invokeAuthorize(acceptedId);
    assertEquals("Accepted", result);
  }

  @Test
  void testAuthorize_Rejected() {
    String rejectedId = "volvoev-highway-fastcharge-unit-77";
    String result = invokeAuthorize(rejectedId);
    assertEquals("Rejected", result);
  }

  @Test
  void testAuthorize_Unknown() {
    String unknownId = "Invalid-station-xyz";
    String result = invokeAuthorize(unknownId);
    assertEquals("Invalid", result);
  }

  @Test
  void testAuthorize_Invalid_ShortLength() {
    String shortId = "short-id";
    String result = invokeAuthorize(shortId);
    assertEquals("Invalid", result);
  }

  @Test
  void testAuthorize_Invalid_Null() {
    String result = invokeAuthorize(null);
    assertEquals("Invalid", result);
  }

  @Test
  void testConsume_SendsCorrectKafkaMessage() {
    String requestId = "req-12345";
    String driverId = "evchargingstation-centralhub-001"; // whitelisted and accepted

    // Build mock AuthorizationRequest
    DriverIdentifier driverIdentifier = new DriverIdentifier();
    driverIdentifier.setId(driverId);

    AuthorizationRequest authorizationRequest = new AuthorizationRequest();
    authorizationRequest.setDriverIdentifier(driverIdentifier);

    // Build AuthenticationRequest
    AuthenticationRequest authRequest = AuthenticationRequest.builder()
        .requestId(requestId)
        .authorizationRequest(authorizationRequest)
        .build();

    // Act
    consumer.consume(authRequest);

    // Capture arguments passed to KafkaTemplate
    ArgumentCaptor<String> keyCaptor = ArgumentCaptor.forClass(String.class);
    ArgumentCaptor<AuthenticationResponse> valueCaptor = ArgumentCaptor.forClass(AuthenticationResponse.class);

    verify(kafkaTemplate, times(1)).send(eq("auth-responses"), keyCaptor.capture(), valueCaptor.capture());

    assertEquals(requestId, keyCaptor.getValue());
    AuthenticationResponse response = valueCaptor.getValue();
    assertEquals(requestId, response.getRequestId());
    assertEquals("Accepted", response.getAuthorizationStatus());
  }

  // Helper method to invoke private authorize method using reflection (or change to package-private for testing)
  private String invokeAuthorize(String id) {
    // Use reflection since authorize() is private
    try {
      var method = AuthenticationRequestConsumer.class.getDeclaredMethod("authorize", String.class);
      method.setAccessible(true);
      return (String) method.invoke(consumer, id);
    } catch (Exception e) {
      throw new RuntimeException("Failed to invoke authorize()", e);
    }
  }
}
