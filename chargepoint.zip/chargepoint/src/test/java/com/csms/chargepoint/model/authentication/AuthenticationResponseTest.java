package com.csms.chargepoint.model.authentication;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class AuthenticationResponseTest {

  @Test
  void testBuilderAndGetters() {
    AuthenticationResponse response = AuthenticationResponse.builder()
        .requestId("req-123")
        .authorizationStatus("Accepted")
        .build();

    assertEquals("req-123", response.getRequestId());
    assertEquals("Accepted", response.getAuthorizationStatus());

    // Also test setters
    response.setAuthorizationStatus("Rejected");
    assertEquals("Rejected", response.getAuthorizationStatus());
  }
}
