package com.csms.chargepoint.model.authentication;

import com.csms.chargepoint.model.authorization.AuthorizationRequest;
import lombok.*;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class AuthenticationRequest {
  private String requestId;
  private AuthorizationRequest authorizationRequest;
}
