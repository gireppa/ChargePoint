package com.csms.chargepoint.consumer;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.csms.chargepoint.model.authentication.AuthenticationResponse;
import com.csms.chargepoint.model.authorization.AuthorizationResponse;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AuthenticationResponseConsumer {
  private Map<String, CompletableFuture<AuthorizationResponse>> map = new ConcurrentHashMap<>();

  public CompletableFuture<AuthorizationResponse> registerRequest(String correlationId) {
    CompletableFuture<AuthorizationResponse> future = new CompletableFuture<>();
    map.put(correlationId, future);
    return future;
  }


  @KafkaListener(topics = "auth-responses", groupId = "backend-service")
  public void consume(AuthenticationResponse response) {
    log.info("Authentication result for correlationId:{}, status:{}", response.getRequestId(), response.getAuthorizationStatus());

    AuthorizationResponse res = new AuthorizationResponse(response.getAuthorizationStatus());
    CompletableFuture<AuthorizationResponse> future = map.remove(response.getRequestId());
    if (future != null) {
      future.complete(res);
    }
  }
}
