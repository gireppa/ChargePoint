package com.csms.chargepoint.model.authorization;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuthorizationRequest {
  private String stationUuid;
  private DriverIdentifier driverIdentifier;
}