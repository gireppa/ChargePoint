package com.csms.chargepoint.consumer;

import com.csms.chargepoint.model.authentication.AuthenticationRequest;
import com.csms.chargepoint.model.authentication.AuthenticationResponse;
import com.csms.chargepoint.model.authorization.AuthorizationRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Service
@Slf4j
public class AuthenticationRequestConsumer {

  private final KafkaTemplate<String, AuthenticationResponse> kafkaTemplate;
  private static final Map<String, Boolean> whitelist = new HashMap<>();

  static {
    whitelist.put("evchargingstation-centralhub-001", true);
    whitelist.put("greenenergy-fastchargepoint-2024", true);
    whitelist.put("urban-electric-vehicle-station-105", false);
    whitelist.put("volvoev-highway-fastcharge-unit-77", false);
  }

  public AuthenticationRequestConsumer(KafkaTemplate<String, AuthenticationResponse> kafkaTemplate) {
    this.kafkaTemplate = kafkaTemplate;
  }

  @KafkaListener(topics = "auth-requests", groupId = "auth-service")
  public void consume(AuthenticationRequest authenticationRequest) {
    log.info("In AuthenticationRequestConsumer request:{}", authenticationRequest);

    AuthorizationRequest authorizationRequest = authenticationRequest.getAuthorizationRequest();
    String driverId = authorizationRequest.getDriverIdentifier().getId();
    String status = authorize(driverId);

    AuthenticationResponse response = AuthenticationResponse.builder()
        .authorizationStatus(status)
        .requestId(authenticationRequest.getRequestId()).build();

    log.info("Publisher sending message to TOPIC:{}, correlationId:{}, response:{}", "auth-responses",
        authenticationRequest.getRequestId(), response);
    kafkaTemplate.send("auth-responses", authenticationRequest.getRequestId(), response);
  }

  private String authorize(String identifier) {
    if (identifier == null || identifier.length() < 20 || identifier.length() > 80) {
      return "Invalid";
    }
    if (!whitelist.containsKey(identifier)) {
      return "Unknown";
    }

    return whitelist.get(identifier) ? "Accepted" : "Rejected";
  }
}
