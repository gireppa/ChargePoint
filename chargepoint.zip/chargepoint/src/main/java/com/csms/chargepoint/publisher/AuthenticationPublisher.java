package com.csms.chargepoint.publisher;

import com.csms.chargepoint.model.authentication.AuthenticationRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AuthenticationPublisher {
  private final KafkaTemplate<String, AuthenticationRequest> kafkaTemplate;

  public AuthenticationPublisher(KafkaTemplate<String, AuthenticationRequest> kafkaTemplate) {
    this.kafkaTemplate = kafkaTemplate;
  }

  public void sendAuthenticationRequest(AuthenticationRequest request, String correlationId) {
      // send request to Kafka topic: auth-request
    log.info("Publisher sending message to TOPIC:{}, correlationId:{}, request:{}", "auth-requests", correlationId, request);
    kafkaTemplate.send("auth-requests", correlationId, request);
  }
}
