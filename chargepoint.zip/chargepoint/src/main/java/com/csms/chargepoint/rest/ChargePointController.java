package com.csms.chargepoint.rest;

import com.csms.chargepoint.consumer.AuthenticationResponseConsumer;
import com.csms.chargepoint.model.authentication.AuthenticationRequest;
import com.csms.chargepoint.model.authorization.AuthorizationRequest;
import com.csms.chargepoint.model.authorization.AuthorizationResponse;
import com.csms.chargepoint.publisher.AuthenticationPublisher;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.apache.coyote.BadRequestException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping("/authenticate")
@Slf4j
public class ChargePointController {

  private final AuthenticationPublisher authenticationPublisher;
  private final AuthenticationResponseConsumer responseConsumer;

  public ChargePointController(AuthenticationPublisher authenticationPublisher,
                               AuthenticationResponseConsumer responseConsumer) {
    this.authenticationPublisher = authenticationPublisher;
    this.responseConsumer = responseConsumer;
  }

  @PostMapping
  public ResponseEntity<AuthorizationResponse> authorize(@Valid @RequestBody AuthorizationRequest request) {
    String correlationId = UUID.randomUUID().toString();
    log.info("Processing authorization request for correlationId: {}", correlationId);

    CompletableFuture<AuthorizationResponse> future = responseConsumer.registerRequest(correlationId);

    try {
      AuthenticationRequest authRequest = convertToAuthenticationRequest(request, correlationId);
      authenticationPublisher.sendAuthenticationRequest(authRequest, correlationId);

      log.debug("Awaiting authentication response for correlationId: {}", correlationId);
      AuthorizationResponse response = future.get(5, TimeUnit.SECONDS);
      log.info("Authorization completed successfully for correlationId: {}", correlationId);

      return ResponseEntity.ok(response);
    } catch (Exception e) {
      log.error("Error processing authorization request for correlationId: {}", correlationId, e);
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
  }

  private AuthenticationRequest convertToAuthenticationRequest(AuthorizationRequest request, String correlationId) throws BadRequestException {
    if (request == null) {
      throw new BadRequestException("AuthorizationRequest cannot be null");
    }
    
    if (!StringUtils.hasText(request.getStationUuid())) {
      throw new BadRequestException("Station UUID is required");
    }
    
    if (request.getDriverIdentifier() == null) {
      throw new BadRequestException("Driver identifier is required");
    }
    
    if (!StringUtils.hasText(request.getDriverIdentifier().getId())) {
        throw new BadRequestException("Driver identifier ID is required");
    }
    return AuthenticationRequest.builder()
        .requestId(correlationId)
        .authorizationRequest(request)
        .build();
  }
}
